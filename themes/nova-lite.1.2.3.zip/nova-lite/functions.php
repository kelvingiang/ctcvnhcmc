<?php

/**
 *
 * Sueva Theme Functions
 *
 * This is your standard WordPress
 * functions.php file.
 *
 * @author  Alessandro Vellutini
 *
*/

require_once dirname(__FILE__) . '/core/main.php';

?>