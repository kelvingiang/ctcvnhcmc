<?php get_header(); ?>

<section id="subheader">
	<div class="container">
    	<div class="row">
            <div class="span12">
				<h1><?php _e( 'Not found','novalite'); ?> </h1>
            </div>        
		</div>
    </div>
</section>

<div class="container" style="position:relative">
	<div class="row" id="portfolio" >
		
		
        <div class="pin-article span12">

			<article class="article">
            
				<p><?php _e( 'Sorry, no posts matched your criteria','novalite'); ?> </p>
 
			</article>

    	</div>
		
           
    </div>
</div>

<?php get_footer(); ?>