<?php 

	get_header(); 
	
	novalite_header_content();
	
	get_template_part('home-blog');
	
	get_footer(); 

?>